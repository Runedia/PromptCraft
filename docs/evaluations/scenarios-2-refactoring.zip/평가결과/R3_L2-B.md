# R3 / L2-B 평가 — obscura `pi004` 리팩토링

- 대상 worktree: `E:/Project/temp/pi/obscura-pi004` (branch `pi004`, uncommitted)
- 시나리오 입력: `E:/Project/PromptCraft/시나리오2/L2-B_promptcraft.txt`
- AI 응답: `E:/Project/PromptCraft/시나리오2/결과3/L2-B_promptcraft_result.txt`
- 레벨/스타일: **L2-B** (Tinkerer / PromptCraft 구조화)
- 공통 의도: `run_parallel_scrape` God function 분해 + worker IPC 타입 통합 + 에러 enum 도입

---

## 0. 변경 인벤토리 (git)

| 종류 | 파일 | 상태 |
|---|---|---|
| Modified | `crates/obscura-cli/Cargo.toml` | `thiserror` 의존 추가 (1줄) |
| Modified | `crates/obscura-cli/Cargo.lock` | 자동 갱신 |
| Modified | `crates/obscura-cli/src/main.rs` | 1337 → **1093줄** (-244) |
| Modified | `crates/obscura-cli/src/worker.rs` | 142 → **109줄** (-33) |
| Untracked | `crates/obscura-cli/src/protocol.rs` | 신규 82줄 |
| Untracked | `crates/obscura-cli/src/scrape.rs` | 신규 332줄 |

응답 보고서의 라인 카운트(82 / 332 / 1093 / 109)는 실제 파일과 **완전 일치**.

---

## 1. 정량 지표 (G2~G10)

> cargo check는 금지(평가 룰). 정적 분석으로 한정.

| ID | 항목 | 원본(main) | pi004 | 평가 |
|---|---|---|---|---|
| G2 | `main.rs` 줄 수 | 1337 | **1093** | △ 244줄 감축 (-18%) |
| G3 | `run_parallel_scrape` 위치 / 길이 | `main.rs` 내부, 약 170~200줄 추정 | `scrape.rs:262-332` = **71줄** | God function 분해 성공 |
| G3 | `scrape_one` 신규 헬퍼 | — | `scrape.rs:77-160` = 84줄 | 단일 URL 워커 흐름 분리 |
| G3 | 그 외 헬퍼 (`send_command`, `read_response`, `extract_title`, `extract_eval_result`, `print_results`, `resolve_worker_path`) | — | 6개 헬퍼 추가 | 단일책임 분리 양호 |
| G4-E | `enum WorkerError`(에러 분류) | 0건 | **1건** (`protocol.rs:67`, `#[derive(thiserror::Error)]`) | thiserror 기반, `From<io::Error>` 자동 변환 포함 |
| G4-C | `enum WorkerCommand`(명령) | 1건 (`worker.rs` 단독) | **1건** (`protocol.rs:12`, `Serialize+Deserialize`) | 양방향 직렬화로 격상 — *명령 enum이지 에러 enum이 아님* (혼동 금지) |
| G4 | `Result<*, String>` 잔존 | 1건 | **0건** | 모두 `Result<_, WorkerError>`로 대체 |
| G5-A | 공개 CLI 명령 (`scrape`/`serve`/`fetch`/`mcp`) | 유지 필요 | 호출부 시그니처 동일 (`main.rs:283` `scrape::run_parallel_scrape(urls, eval, concurrency.get(), &format, timeout, quiet, global_proxy)`) | 유지 |
| G5-B | `run_parallel_scrape` 시그니처 보존 | `fn(urls, eval, concurrency, format, timeout_secs, quiet, proxy) -> anyhow::Result<()>` | `scrape.rs:262` 동일 | 외부에서 본 동작 동일 |
| G5-C1 | Cargo.toml 변경 (Scope 위반 여부) | 의존성: tokio/serde/serde_json/anyhow/clap | `thiserror = { workspace = true }` 1줄 추가 | 신규 의존성 1건. 워크스페이스에 이미 정의된 의존성(별도 외부 패키지 신규 도입 아님) → **L2-B의 "cargo build 통과 보장"** Scope와 부합. `thiserror`는 derive-only proc-macro로 런타임 영향 없음. ⚠️ 다만 입력 Scope는 *의존성 변경을 명시 허용하지 않았으므로*, 정확히는 **Scope 경계 케이스**. 응답이 "Cargo.toml — thiserror 의존성 추가"라고 명시 보고했으므로 은닉은 아님 |
| G6 | raw `serde_json::json!` 호출 — `main.rs` | 12건 (실측) | **0건** | 전량 제거 |
| G6 | raw `serde_json::json!` 호출 — `scrape.rs` | — | 3건 | 모두 *출력 직렬화(보고용 JSON 빌드)*에 한정 — IPC 와이어에서는 사용 없음 (의도 부합) |
| G6 | raw `serde_json::json!` 호출 — `worker.rs` | 다수 | 5건 (응답 result payload 빌드용) | IPC 명령 분기는 enum로 이전됨, payload만 남음 — 합리적 잔존 |
| G7 | 단일 모듈 IPC 정의 (중복 제거) | `main.rs`/`worker.rs` 양쪽에 흩어진 JSON 리터럴 | `protocol.rs` 단일 소스. `main.rs:1 mod protocol;`, `worker.rs:6 mod protocol;` (두 `[[bin]]`에서 동일 파일 모듈 포함) | 단일화 OK |
| G8 | 함수 ≥ 200줄 잔존 여부 (`main.rs`) | 다수 추정 | **0건** (최대 `run_fetch` 87줄, `run_multi_worker_serve` 83줄, `main` 77줄) | 모든 함수 200줄 미만 — Concern Area 직접 해소 |
| G9 | 새 파일에 모듈 문서 주석 | — | `protocol.rs` / `scrape.rs` 둘 다 `//!` 모듈 doc 보유, public API 대다수 `///` doc | 양호 |
| G10 | `#[allow(dead_code)]` 사용 | — | `protocol.rs`에 3곳 (cross-bin 사용 미추적 회피) | 명시적 주석으로 정당화. lint 회피지만 **이유 문서화됨** |

### G6 보조 — raw json! 분포 합계

| 위치 | 건수 | 용도 |
|---|---|---|
| `main.rs` | 0 | — |
| `scrape.rs` | 3 | 결과 출력 JSON 직렬화 (IPC 아님) |
| `worker.rs` | 5 | success response의 result payload 빌드 (IPC payload, command/dispatch는 enum) |
| `protocol.rs` | 0 | — |

**핵심**: IPC 명령 분기(`cmd` 태그)에서 raw json! 사라짐. 응답 payload는 본질적으로 동적 타입이므로 `serde_json::Value` 유지가 합리적.

---

## 2. L2-B 3항목 평가

### ① Target Code 분석 — "obscura-cli crate 전체 (main.rs와 worker.rs 위주)"

- AI 응답은 **main.rs / worker.rs 두 파일을 모두 다루었고**, 추가로 `protocol.rs`와 `scrape.rs`를 신설.
- 변경 범위가 `crates/obscura-cli`로 정확히 국한 (다른 크레이트 무수정 — git diff stat 4파일 모두 `crates/obscura-cli` 내부).
- 가설 "대상이 모호해 답변은 main.rs 전반론"은 **부분만 적중**: 실제 응답은 main.rs 전반이 아닌 *Concern Area 키워드에 정렬된 부위(IPC, 에러, run_parallel_scrape)*에만 손댐. → L2-B 구조화 효과 확인.

평가: **충실**.

### ② Concern Area 3개 답변

| 우려사항 | 응답 처리 | 평가 |
|---|---|---|
| 함수 길이 200줄 초과 | `run_parallel_scrape`을 `scrape.rs`로 이동시키며 7개 함수로 분해 (`scrape_one`, `send_command`, `read_response`, `extract_title`, `extract_eval_result`, `print_results`, `resolve_worker_path`). main.rs 잔존 최대 함수 `run_fetch` 87줄 | **해소** |
| `main.rs`/`worker.rs` 간 IPC JSON 중복 | `protocol.rs` 단일 모듈에 `WorkerCommand`(`#[serde(tag="cmd")]`) + `WorkerResponse` 정의, 두 `[[bin]]`이 동일 파일을 `mod protocol;`로 공유 | **해소** |
| `String` 에러 전달 → 타입 안전성 | `thiserror::Error` 기반 `WorkerError` enum (Spawn/Write/Read/Timeout/WorkerError) 도입, `Result<*, String>` 0건 | **해소** |

평가: **3/3 직접 해소**.

### ③ Modification Scope 보존 + 섹션 정렬

- "공개 CLI 인터페이스 유지" — `obscura scrape` 호출부 시그니처/인자 동일 (`main.rs:283`). `serve` / `fetch` / `mcp` 분기 무변경. **유지됨**.
- "cargo build 통과 보장" — 정적 분석 한계 내에서 점검:
  - `main.rs:1 mod protocol; mod scrape;` 선언과 두 신규 파일 존재 → 컴파일 단위 정합.
  - `worker.rs:6 mod protocol;` — `[[bin]] obscura-worker`가 같은 `src/protocol.rs`를 별도 모듈로 포함 (Rust 컴파일러 정책상 정상; 두 바이너리 각자 자기 트리에 포함).
  - 시그니처 일치: `WorkerCommand`/`WorkerResponse` 사용 위치 정합 확인.
  - 다만 cargo check 미실행이므로 **빌드 통과는 미증명**. 코드 형태상 빌드 가능성 매우 높음.
- 응답 보고서 섹션이 입력 카드(target-code / modification-scope / concern-area)와 1:1 정렬되어 있음 — "새 파일 추가 → 수정된 파일 → Cargo.toml" 순으로 변경 범위 → Concern 해소 흐름 그대로.

평가: **Scope 보존 + 섹션 정렬 모두 양호**. 단, `Cargo.toml` 의존성 추가는 Scope 문구가 명시 허용하지 않은 *경계*임 — 응답이 명시 보고하여 투명성 확보.

---

## 3. 커버리지

| 의도 | 충족 |
|---|---|
| God function 분해 | ✅ `run_parallel_scrape` 200줄대 → 71줄 + 6개 헬퍼 |
| IPC 타입 통합 | ✅ `protocol.rs` 단일 소스, 두 바이너리 공유 |
| 에러 enum 도입 | ✅ `WorkerError` (thiserror), `Result<_,String>` 박멸 |
| CLI 표면 보존 | ✅ scrape 시그니처/명령 분기 동일 |
| 문서화 | ✅ 모듈 doc + public API doc 대부분 보유 |
| 빌드 통과 | ⚠️ 정적 정합성 OK, 실측 미수행 (룰상 cargo 금지) |
| Scope 외 변경 최소화 | ⚠️ `thiserror` 1줄 추가 — 보고는 명시됨 |

**미흡/주의 사항**
- `WorkerError::WorkerError(String)` 변체명이 enum명과 중복되어 가독성 손해. `Reported(String)` 등이 적절.
- `protocol.rs`에 `#[allow(dead_code)]` 3곳: cross-`[[bin]]` 추적 한계상 합리적이지만, 향후 라이브러리 추출 시 제거 가능.
- `scrape.rs::ScrapeResult::into_json` 메서드명이 `&self`를 받는데 `into_*` 네이밍 — `to_json`이 컨벤션.
- `print_results`가 `anyhow::Result`를 반환하지만 내부 실패 경로는 `serde_json::to_string_pretty`만 — 합리적 범위.

---

## 4. 종합 등급

| 축 | 점수 | 비고 |
|---|---|---|
| 의도 충족(공통 의도 3항목) | **A** | 분해/통합/enum 전부 직접 해소 |
| Concern Area 해소 | **A** | 키워드 3개 1:1 매핑 |
| Scope 보존 | **B+** | CLI/시그니처 보존, `thiserror` 추가는 경계 케이스이지만 투명 보고 |
| 코드 품질 | **A-** | 분리/문서/타입 안전성 양호. 변체 네이밍·`into_json` 컨벤션 사소한 흠 |
| L2-B 가설 부합 | **부합** | 섹션 분리 → 답변도 섹션별 정렬, target-code 모호함에도 Concern으로 초점 좁힘 |

**종합: A- (우수)**

L2-B 구조화 카드(role/goal/target-code/modification-scope/concern-area)의 분리 입력이 응답을 효과적으로 정렬했으며, AI가 *Target Code 추상성("crate 전체")을 Concern Area 키워드("함수 길이/IPC 중복/에러 타입")로 해석*하여 정확한 부위만 수정. God function 분해 + IPC 단일화 + 에러 enum 세 축이 모두 직접 해소되었고, 공개 CLI 표면이 보존되었으며, 변경 보고가 투명함. 빌드 통과의 실측만 미보장.
