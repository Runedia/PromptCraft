# R2 L2-A 평가 결과

- 시나리오: `L2-A` (Tinkerer / 일반 비구조화 자연어, 항목 나열형)
- 평가 대상: `E:/Project/PromptCraft/시나리오2/project/obscura_R2_L2-A` (브랜치 `gem003`, 커밋 `2fc93e8`)
- 시나리오 입력: `E:/Project/PromptCraft/시나리오2/L2-A_일반.txt` — "main.rs 900줄 넘는데 scrape 명령이 한 덩어리에 다 들어있고 worker.rs와 타입 중복도 있고 에러도 String으로 넘기는 것 같다, 정리해줘"
- AI 응답: `E:/Project/PromptCraft/시나리오2/결과2/L2-A_일반_result.txt`
- 공통 의도: `run_parallel_scrape` God function 분해 + worker IPC 타입 통합 + 에러 enum 도입
- 원본 시그니처: `fn run_parallel_scrape(urls, eval, concurrency, format, timeout_secs, quiet, proxy) -> anyhow::Result<()>`

## 1. 변경 개요 (git)

커밋 1개 (`2fc93e8 L2-A`), 4 files changed, 276 insertions(+), 277 deletions(-). 거의 라인 보존형 이동(분리) + 일부 구조화.

| 파일 | 변화 | 줄 수 |
|---|---|---:|
| `src/main.rs` | -241 / +5 (run_parallel_scrape 본문 제거, `mod scrape; mod protocol;` 선언과 호출경로 `scrape::run_parallel_scrape` 변경만) | 1337 → 1101 |
| `src/scrape.rs` (신규) | `WorkerClient` 구조체 + `run_parallel_scrape` 이전 | 231 |
| `src/protocol.rs` (신규) | `WorkerCommand` enum + `WorkerResponse` struct (공유 IPC 타입) | 37 |
| `src/worker.rs` | 자체 정의했던 `WorkerCommand`/`WorkerResponse` 제거 후 `mod protocol; use protocol::*` | 142 → 109 |

총합: 원본 main.rs 1337줄에 분산되어 있던 IPC/스크레이프 책임이 1101 + 231 + 37 = 1369줄로 재분배. main.rs 축소율 -17.7%.

## 2. 정량 지표 (cargo check 미수행)

| 지표 | 기준값 (main) | 측정값 (gem003) | 판정 |
|---|---:|---:|---|
| G2 — `main.rs` 줄 수 | 1337 | 1101 | OK (-17.7%) |
| G3 — `run_parallel_scrape` 본문 줄 수 | 230 (`main.rs:687~`) | 162 (`scrape.rs:70~231`, IPC 코드 일부가 `WorkerClient` 메서드로 이동) | OK |
| G4 — `run_parallel_scrape` 시그니처 변경 | — | 동일 (`urls, eval, concurrency, format, timeout_secs, quiet, proxy`) | 무변경 (호환 유지) |
| G5 — IPC를 메서드/객체로 추출 | — | `WorkerClient::{spawn, send_command, receive_response, shutdown, kill}` 5개 메서드 도입 | OK |
| G6 — raw `json!` 호출 수 | 12 (원본 `main.rs`의 `run_parallel_scrape` 영역) | 5 (`scrape.rs`) | OK (-58%, 명령 직렬화가 `WorkerCommand` enum으로 대체된 결과) |
| G7 — `Result<*, String>` 잔존 | 1 (`worker_result: Result<serde_json::Value, String>`) | 0 (모두 `anyhow::Result<_>`로 교체) | OK |
| G8 — `enum *Error` 도입 (`thiserror` 등) | 0 | 0 | FAIL (의도 미충족 — `anyhow` 채택은 enum 도입은 아님) |
| G9 — worker IPC 타입 통합 (`WorkerCommand`/`WorkerResponse` 공유) | — | `src/protocol.rs` 신설, `worker.rs`와 `scrape.rs`가 동일 모듈을 `mod protocol;`로 직접 포함 | OK |
| G10 — 회귀 / 동작 변화 | — | **`worker_timeout` 외부 래퍼 제거** (원본 `timeout(worker_timeout, async {...})`이 사라지고 `_worker_timeout`으로 미사용 변수화) → 워커 전체 작업 상한 시간 보장이 사라짐. read_timeout만 남아 명령별 read에는 상한이 있으나, 워커 라이프사이클 전체에 대한 타임아웃은 부재 | FAIL (기능 회귀) |
| G11 — 저장소 위생 | — | 작업 잔재 파일 없음, .gitignore 변동 없음 | OK |

부가 관찰:
- **`mod protocol;` 이중 선언 패턴**: `main.rs`와 `worker.rs` 양쪽이 각자 `mod protocol;`을 선언 (두 바이너리가 같은 `src/` 디렉터리를 공유하므로 컴파일 단위가 분리됨). Cargo `[[bin]]` 구조상 정상 동작은 하나, 보다 깔끔한 방법은 `lib.rs`(or `protocol.rs`를 라이브러리화)로 노출해 공유하는 형태. 현재 구현은 "선언만 공유, 파일 위치만 동일"이며 컴파일은 두 번 일어남.
- `WorkerResponse`에 `#[allow(dead_code)]` 부착됨 — `error()` 헬퍼가 `worker.rs`에서만 사용되어 `main`(=cli) 측에서 미사용으로 잡히기 때문. 추정상 lint 경고 회피용이며, 정상 신호.
- `cargo check`/`cargo test` 통과 여부는 AI 응답에 "전부 정상 동작 확인 완료"라고 주장만 있고 본 평가에서는 미실행 (지시 사항). 다만 코드상 명백한 컴파일 에러는 보이지 않음.

## 3. 시나리오 커버리지 (L2-A 4항목)

| 요청 항목 | 기대 행동 | 실제 결과 | 판정 |
|---|---|---|---|
| ① "main.rs가 900줄 넘는데 scrape 처리 함수가 한 덩어리" → 분해 | `run_parallel_scrape` 책임 분리 | `WorkerClient` 객체로 spawn/send/receive/shutdown/kill 5메서드 추출. 본문 230 → 162줄. 함수 자체는 단일이지만 IPC 책임이 메서드로 이전됨 | 충족 |
| ② "worker.rs에 비슷한 타입 또 있는 것 같다" → IPC 중복 식별·통합 | `WorkerCommand`/`WorkerResponse`를 한 곳에 정의 | `src/protocol.rs` 신설, `worker.rs`와 `scrape.rs`가 같은 모듈을 공유. 단, 원본 main.rs는 IPC 타입을 가지지 않고 raw `json!`로 메시지를 직조했었음 — AI 응답의 "양쪽에서 하드코딩되거나 중복 선언되어 있던" 표현은 부정확 (worker만 정의, main은 untyped raw JSON이었음). 그러나 결과적으로 양쪽 타입 사용 통일은 달성 | 충족 |
| ③ "에러 그냥 String으로 넘기는 것 같다" → 타입화 | `enum Error` (또는 `thiserror`) 도입 | enum 미도입. `Result<_, String>` 잔존을 모두 `anyhow::Result<_>`로 교체하는 데 그침 (개선이지만 분류 가능한 enum은 아님). AI 응답도 "anyhow::Result 반환"이라고 명시 — 시나리오 의도와의 불일치를 본인이 인지한 채 의도적으로 단순화 | 부분 충족 |
| ④ 수정 코드 제시 | 변경된 파일을 직접 적용 | 4개 파일 실제 수정/추가, 커밋까지 완료 | 충족 |

세부:
- AI는 재질문 0회, One-Shot으로 처리. L2-A 시그니처(항목 나열 + 추상도) 대비 응답 정확도는 비교적 높음 — 사용자가 명시한 3가지 항목을 모두 인지하고 항목별로 응답함.
- 다만 ③항(에러 타입화)에서 `enum`이 아닌 `anyhow`를 선택한 것은 명시적 trade-off. "추적은 쉽게, 분류는 포기" 라인. 시나리오가 요구한 "타입화"의 1차 해석(enum/매칭 가능)이 아니라, 2차 해석(컨텍스트 부여)로 우회. 사용자가 "타입화"의 정확한 의미를 명시하지 않은 L2 시그니처를 고려하면 합리적 절충이지만, 평가 기준의 의도는 미충족.
- 응답 텍스트 자체는 한국어로 간결 (3개 작업 + 검증 주장). 다만 `worker_timeout` 회귀에 대한 언급 0건 — AI가 인지하지 못했거나 의도적으로 제거했는지 불명.

## 4. 강점

- 강점1 — `WorkerClient` 도입이 의미 있는 추상화. `spawn` / `send_command` / `receive_response` / `shutdown` / `kill` 5메서드로 워커 라이프사이클을 캡슐화. 원본의 `child.stdin.take()`/`stdout.take()`/수동 BufReader 패턴이 제거됨.
- 강점2 — IPC 타입 통합이 실제로 동작. `protocol.rs`의 단일 `WorkerCommand` enum / `WorkerResponse` struct를 `worker.rs`와 `scrape.rs`가 공유. 라인 프로토콜 변경 시 한 곳만 수정하면 됨.
- 강점3 — raw `json!` 호출 -58% 감소. `serde_json::json!({"cmd":"navigate", ...})` 직조 코드가 `serde_json::to_string(&WorkerCommand::Navigate { url })` 형태로 정형화.
- 강점4 — `Result<_, String>` 잔존 0건. 비록 enum은 아니지만 `anyhow::Result` 일관화로 에러 컨텍스트(`.context()`, `anyhow::bail!`) 활용 가능.
- 강점5 — main.rs 호출부 변경 최소화 (`run_parallel_scrape` → `scrape::run_parallel_scrape` 1줄). API 호환성 유지.
- 강점6 — 응답에서 사용자의 3가지 항목(분해/중복/에러)을 명시적으로 1·2·3 번호 매겨 답함. 의도 정합성 인식 양호.

## 5. 약점 / 미충족 항목

- 약점1 — **`worker_timeout` 외부 래퍼 제거 (기능 회귀)**. 원본은 `timeout(worker_timeout, async { 워커 전체 수명 })`으로 워커 작업 전체에 상한 시간을 걸었다. 새 코드는 `let _worker_timeout = Duration::from_secs(timeout_secs);`로 변수만 만들고 사용하지 않음. `--timeout` CLI 플래그의 의미가 부분 손실 (read_timeout만 유효, 워커 라이프사이클 전체에 대한 상한은 없음). 악성 워커가 navigate 응답 후 hang하면 read_timeout보다 길게 점유 가능.
- 약점2 — **`enum Error` 미도입 (의도 미충족)**. 시나리오 ③항은 "String → 타입화"인데 채택된 것은 `anyhow::Result`. anyhow는 dynamic error trait object이고 `thiserror`-기반 enum과는 분류·매칭 가능성에서 차이가 큼. `match error { ScrapeError::Timeout => ..., ScrapeError::Spawn(_) => ... }` 같은 분기 불가.
- 약점3 — **AI 응답의 사실관계 부정확**. "main.rs와 worker.rs 양쪽에서 하드코딩되거나 중복 선언되어 있던 WorkerCommand와 WorkerResponse" — main.rs는 해당 타입을 **선언한 적 없음**. raw `json!` 매크로로 메시지를 직조했고, worker.rs만 enum/struct를 가졌다. 결과물은 합리적이지만 진단 문구는 사실과 다름.
- 약점4 — **`WorkerResponse::receive_response`의 invalid JSON 폴백이 과한 swallow**. `serde_json::from_str(resp_line.trim()).unwrap_or_else(|_| WorkerResponse::error("invalid JSON response"))` — 파싱 실패를 에러로 변환해 `Ok(response)`로 반환. 즉 `nav_resp.ok == false` 분기로 흘러가지만 호출자는 "워커 응답을 받았다"고 판단. `anyhow::bail!("invalid JSON: {}", line)`이 더 정확.
- 약점5 — **`mod protocol;` 이중 선언으로 protocol.rs가 두 번 컴파일됨**. `obscura-cli`와 `obscura-worker`가 동일 `src/`를 공유하는 멀티 바이너리 구조에서, 진정한 공유라면 `lib.rs`로 분리해 `[lib] + [[bin]]` 패턴이 표준. 현재 구조는 동작은 하나 "타입을 공유했다"기보다 "정의 위치만 통일했다"에 가깝고, 컴파일 단위 관점에서는 두 개의 `protocol` 모듈이 별도로 존재.
- 약점6 — 재질문 0회. L2-A의 가설("재질문 1회 내외")에는 부합하나, ③항의 enum 의도를 묻는 1회 재질문이 있었으면 충족도 상승 여지 있었음. 자체 판단으로 anyhow 채택.
- 약점7 — `cargo test/check` 검증 주장 검증 불가 (cargo 실행 금지). 응답의 "확인 완료" 문구는 정황상 합당하나 본 평가에서는 확정 불가.

## 6. 종합 등급

**B+ (대체로 충족, enum·timeout 회귀로 감점)**

- 시나리오 4항 중 3항(① 분해, ② IPC 통합, ④ 수정 코드 제시) **충족**, 1항(③ 에러 타입화) **부분 충족** (`enum` 대신 `anyhow`).
- 정량 지표 G2/G3/G5/G6/G7/G9/G11 OK, G8 FAIL (enum 미도입), G10 FAIL (worker_timeout 회귀).
- L2-A 가설("재질문 1회 내외, 답변은 표면적 분리 제안에 그칠 가능성") 대비 — 재질문 0회는 적중, 그러나 "표면적"이라는 부분은 빗나감 (`WorkerClient` 추상화는 표면을 넘어선 실질적 캡슐화).
- 동일 공통 의도를 가진 L1-A(C, 0/3 충족)와 비교하면 큰 격차로 상회. L2 시그니처의 항목 나열이 AI의 작업 범위 정의에 실질적 도움을 줌.

### 권장 후속 조치
1. `let worker_timeout = Duration::from_secs(timeout_secs);`로 복원 후, `scrape.rs:135` 부근의 `async { ... }.await`를 `timeout(worker_timeout, async { ... }).await?` 형태로 감싸 워커 전체 상한을 복귀.
2. `enum ScrapeError { Spawn(std::io::Error), Io(std::io::Error), Timeout, NavigateFailed(String), EvaluateFailed(String), InvalidResponse(String), WorkerNotFound(PathBuf) }` 도입 + `thiserror::Error` derive. `WorkerClient` 메서드 반환을 `Result<_, ScrapeError>`로 좁힌 뒤 호출부에서 `anyhow::Result`로 흡수.
3. `protocol.rs`를 진짜 공유 모듈로 — `crates/obscura-cli`를 `lib + 2 bin`으로 재구성하거나 별도 `obscura-ipc` 크레이트로 추출. 현 구조는 컴파일 단위 공유가 아닌 소스 코드 공유에 그침.
4. `receive_response`의 invalid JSON을 silent error response가 아닌 `anyhow::Error`로 즉시 bail.
5. `WorkerResponse::error`에 `#[allow(dead_code)]`를 제거할 수 있도록, cli 측에서도 사용처(예: invalid JSON 변환 helper)에 도입.
