# R2 L1-A 평가 결과

- 시나리오: `L1-A` (Observer / 일반 비구조화 자연어)
- 평가 대상: `E:/Project/PromptCraft/시나리오2/project/obscura_R2_L1-A` (브랜치 `gem001`, 커밋 `e29b819`)
- 시나리오 입력: `E:/Project/PromptCraft/시나리오2/L1-A_일반.txt` — "obscura-cli 코드 좀 정리해줘"
- AI 응답: `E:/Project/PromptCraft/시나리오2/결과2/L1-A_일반_result.txt`
- 공통 의도: `run_parallel_scrape` God function 분해 + worker IPC 타입 통합 + 에러 enum 도입
- 원본 시그니처: `fn run_parallel_scrape(urls, eval, concurrency, format, timeout_secs, quiet, proxy) -> anyhow::Result<()>`

## 1. 변경 개요 (git)

커밋 1개, 8 files changed, 908 insertions(+), 882 deletions(-).

| 파일 | 변화 |
|---|---|
| `src/main.rs` | 1337 → 470 줄 (분할 후 남은 진입점) |
| `src/cli.rs` (신규) | 149 줄 — `Args`, `Command`, `DumpFormat` 등 clap 정의 |
| `src/utils.rs` (신규) | 68 줄 — `print_banner`, `select_log_filter`, `merge_proxy`, `normalize_v8_flags`, `reject_stealth_with_socks5`, `is_quiet_command` |
| `src/commands/mod.rs` (신규) | 7 줄 — 모듈 선언 + re-export |
| `src/commands/fetch.rs` (신규) | 293 줄 |
| `src/commands/scrape.rs` (신규) | 242 줄 |
| `src/commands/serve.rs` (신규) | 126 줄 |
| `src/worker.rs` | 변동 없음 (142 줄, `WorkerCommand`/`WorkerResponse` 기존 그대로) |
| `src/refactor.py` (신규) | 8 줄 — 작업용 스크립트 잔재 (저장소 오염) |

총 라인: 1337(원본 main.rs) → 1355(분할본 합계) — 거의 동일, 즉 **분할 위주이고 분해/축소는 일어나지 않음**.

## 2. 정량 지표 (cargo check 미수행)

| 지표 | 기준값 (main) | 측정값 (gem001) | 판정 |
|---|---:|---:|---|
| G2 — `main.rs` 줄 수 | 1337 | 470 | OK (-65%) |
| G3 — `run_parallel_scrape` 본문 줄 수 | 230 (`main.rs:687~`) | 235 (`commands/scrape.rs:7~242`) | FAIL (시그니처·로직 동일, 위치만 이동) |
| G4 — `run_parallel_scrape` 시그니처 변경 | — | 동일 (`urls, eval, concurrency, format, timeout_secs, quiet, proxy`) | 무변경 |
| G5 — `run_parallel_scrape` 내부 helper 추출 | — | 0 (스폰/IPC/집계 일체화된 단일 async block 유지) | FAIL |
| G6 — raw `json!` 호출 수 | 9 | 12 (`scrape.rs` 단일 파일에서만 측정) / 17 (`scrape.rs` + `worker.rs`) | FAIL (오히려 증가) |
| G7 — `Result<*, String>` 잔존 | 1 | 1 (`scrape.rs:103`) | 무변경 |
| G8 — `enum *Error` 도입 | 0 | 0 | FAIL (의도 미충족) |
| G9 — worker IPC 타입 통합 (`WorkerCommand`/`WorkerResponse` 공유) | — | 미수행. `scrape.rs`는 여전히 인라인 `json!` 메시지를 직렬화하고 `serde_json::Value`로 응답 파싱 (`worker.rs`의 기존 enum/struct를 import·재사용하지 않음) | FAIL |
| G10 — 저장소 위생 | — | `crates/obscura-cli/refactor.py`(작업 잔재) 커밋, `.gitignore`/정리 누락 | FAIL |

부가 관찰:
- `commands/mod.rs`가 `pub use ...`로 진입점을 그대로 재노출하여 main.rs에서의 호출 형태는 무변동. **API/시그니처 호환성은 유지**.
- `cargo check`/`cargo test` 통과 여부는 AI 응답에 "확인했다"는 주장만 있고 본 평가에서는 미실행 (지시 사항).

## 3. 시나리오 커버리지 (L1-A 1항목)

| 요청 항목 | 기대 행동 | 실제 결과 | 판정 |
|---|---|---|---|
| C1 — "obscura-cli 코드 좀 정리해줘" (대상·범위·기준 모두 부재) | (가설) "어느 부분?/목적?" 재질문 또는 대상 명확화 요청 | 재질문 0회, 자체 판단으로 모듈 분할만 단행. 공통 의도(God function 분해, IPC 타입 통합, 에러 enum)는 인지·언급조차 없음 | 부분 충족 |

세부:
- AI는 "코드를 모듈별로 정리"라는 좁은 해석 1가지만 수행. 응답 텍스트는 `cli.rs/utils.rs/commands/*.rs` 파일 분리 사실만 보고.
- 결과는 가시적 정리이지만, **공통 의도 3축(분해/IPC 통합/에러 enum) 중 어느 것도 수행되지 않음**.
- L1 시그니처(대상 미지정 → 추측 의존)와 가설(재질문 ≥ 2회) 중 "재질문 0회"는 가설에서 벗어남 — 모델이 멈추지 않고 자체 추정으로 진행.

## 4. 강점

- 강점1 — `main.rs` 1337 → 470줄로 가독성 개선. clap 정의/유틸/3개 서브커맨드를 독립 파일로 분리한 구조 자체는 합리적.
- 강점2 — `commands/mod.rs`의 `pub use`로 호출부 영향 최소화, 상위 진입점(`main` async block) 동작 일치 유지.
- 강점3 — `cli.rs`, `utils.rs` 분리로 단위 테스트 import 경로(`crate::cli::*`, `crate::utils::*`)가 의미적으로 명확해짐.

## 5. 약점 / 미충족 항목

- 약점1 — `run_parallel_scrape` 분해 0건. 230줄 함수가 단일 async block 그대로 새 파일로 이전됨. 워커 스폰 / nav 명령 송수신 / eval 송수신 / shutdown / 결과 집계 어느 것도 helper 함수로 빠지지 않음. **공통 의도 핵심 항목 미수행.**
- 약점2 — IPC 타입 통합 미수행. `worker.rs`에는 이미 `WorkerCommand` enum / `WorkerResponse` struct가 존재하나, `scrape.rs`는 그대로 `serde_json::json!({"cmd": "navigate", ...})` / `serde_json::Value` 파싱을 사용. 두 측이 공통 타입을 공유하지 않아 라인 프로토콜 변경 시 양쪽이 동시에 깨질 위험 잔존.
- 약점3 — `enum Error` 도입 0건. 현재 `Result<serde_json::Value, String>`과 `&str` 리터럴(`"Write failed"`, `"Read failed"`, `"timeout"`) 그대로. 에러 분류·매칭 불가.
- 약점4 — raw `json!` 호출이 `scrape.rs` 한 파일 기준으로 9 → 12건으로 증가 (원본 `json!` 산재 위치가 한곳으로 모인 결과로 보임). 즉 정리는 했으되 raw JSON 의존 자체는 줄지 않음.
- 약점5 — `refactor.py` 작업 스크립트가 커밋에 포함됨. 빈 로직(주석만 있는 미완성)인데도 저장소에 남음 → 위생 불량.
- 약점6 — AI가 "cargo check/test 통과 확인"이라고 명시했으나 응답 외 검증 흔적이 변경에 포함되어 있지 않음. 본 평가에서 cargo 실행 금지이므로 주장의 진위는 미확정.
- 약점7 — 재질문 0회. L1-A의 의도(대상·범위 미지정 → 명확화 유도)를 활용하지 못함. 모델이 자의로 범위를 좁힘.

## 6. 종합 등급

**C (부분 충족)**

- 표면 리팩토링(파일 분할, `main.rs` 축소)은 성공했고 호출부 호환성도 유지. 가독성 측면의 단기 이득은 있음.
- 그러나 본 시나리오의 **공통 의도 3축 — God function 분해 / IPC 타입 통합 / 에러 enum 도입 — 모두 미수행**. 정량 지표 G3, G5, G6, G7, G8, G9, G10가 FAIL.
- L1-A 가설("재질문 ≥ 2회, One-Shot 성공률 낮음") 중 "One-Shot 성공률 낮음"은 정확히 관찰됨 (의도 대비 표면만 처리). "재질문 ≥ 2회"는 빗나감 (0회).

### 권장 후속 조치
1. `scrape.rs`의 `run_parallel_scrape`를 `spawn_worker` / `send_navigate` / `send_evaluate` / `shutdown_worker` / `collect_results` 5함수 이상으로 분해.
2. `worker.rs`의 `WorkerCommand` / `WorkerResponse`를 `obscura-cli`의 공용 모듈(예: `ipc.rs`)로 이전하고 `scrape.rs`에서 import하여 `serde_json::to_string(&WorkerCommand::Navigate { url })` 형태로 사용.
3. `enum ScrapeError { Spawn(io::Error), Io(io::Error), Timeout, NavigateFailed(String), ... }` 도입 + `thiserror` 사용, `Result<_, String>` 제거.
4. `refactor.py` 제거, `.gitignore` 갱신.
