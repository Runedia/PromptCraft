# R3 L2-A 평가 결과

- 시나리오: `L2-A` (Tinkerer / 일반 비구조화 자연어, 항목 나열형)
- 평가 대상: `E:/Project/temp/pi/obscura-pi003` (worktree, 브랜치 `pi003`, **uncommitted**)
- 시나리오 입력: `E:/Project/PromptCraft/시나리오2/L2-A_일반.txt` — "main.rs 900줄 넘는데 scrape 명령이 한 덩어리에 다 들어있고 worker.rs와 타입 중복도 있고 에러도 String으로 넘기는 것 같다, 정리해줘"
- AI 응답: `E:/Project/PromptCraft/시나리오2/결과3/L2-A_일반_result.txt`
- 공통 의도: `run_parallel_scrape` God function 분해 + worker IPC 타입 통합 + 에러 enum 도입
- 원본 시그니처: `fn run_parallel_scrape(urls, eval, concurrency, format, timeout_secs, quiet, proxy) -> anyhow::Result<()>`

## 1. 변경 개요 (git)

uncommitted 상태 (커밋 없음). `git status --short` 결과:

```
 M crates/obscura-cli/src/main.rs
 M crates/obscura-cli/src/worker.rs
?? crates/obscura-cli/src/error.rs
?? crates/obscura-cli/src/scrape.rs
```

`git diff HEAD --stat`: 2 files changed, 42 insertions(+), 261 deletions(-) (untracked 제외).

| 파일 | 변화 | 줄 수 |
|---|---|---:|
| `crates/obscura-cli/src/main.rs` | -239 / +19 — `run_parallel_scrape` 본문 240줄 통째 제거, `mod error; mod scrape; mod worker;` 선언과 호출경로 `scrape::run_parallel_scrape` 변경 | 1337 → 1117 |
| `crates/obscura-cli/src/scrape.rs` (신규, untracked) | `WorkerClient` (spawn/send_cmd/navigate/evaluate/shutdown/kill) + `scrape_one` + `collect_results` + `format_json/format_text` + `run_parallel_scrape` 진입점 | 345 |
| `crates/obscura-cli/src/error.rs` (신규, untracked) | `enum ScrapeError` (5 variant) + `struct ScrapeResult` + Display/Error impl | 50 |
| `crates/obscura-cli/src/worker.rs` | 타입 `pub`화 + `Deserialize` 추가 + `write_response` 헬퍼 추출 | 142 → 143 |

총합: 원본 main.rs 1337줄에 응축되어 있던 IPC/스크레이프 책임이 1117 + 345 + 50 + 143 = 1655줄로 재분배. main.rs 축소율 -16.5%. AI 응답이 주장한 "main.rs ~720줄(로직) + 394줄(테스트)" 수치는 부정확 — 실측 1117줄 전체.

## 2. 정량 지표 (cargo check 미수행)

| 지표 | 기준값 (main) | 측정값 (pi003) | 판정 |
|---|---:|---:|---|
| G2 — `main.rs` 줄 수 | 1337 | 1117 | OK (-16.5%, AI 자체 보고 수치 720줄은 부정확) |
| G3 — `run_parallel_scrape` 본문 줄 수 | 230 (`main.rs`) | 0줄 (main.rs에서 완전 제거) / `scrape.rs:290~345`에 56줄 진입점 (`bail!` 검증 + worker_path 탐색 + `collect_results` 호출 + 포맷 분기만) | OK (대폭 축소 + 책임 분리) |
| G4 — `run_parallel_scrape` 시그니처 | — | 동일 (`urls, eval, concurrency, format, timeout_secs, quiet, proxy -> anyhow::Result<()>`) | 무변경 (호환 유지) |
| G5 — IPC를 메서드/객체로 추출 | — | `WorkerClient::{spawn, send_cmd, navigate, evaluate, shutdown, kill}` 6 메서드 + `Drop` 구현으로 best-effort cleanup. `ScrapeTaskConfig` 구조체로 인자 묶음 | OK (정점) |
| G6 — raw `json!` 호출 수 (`main.rs` + `scrape.rs`) | 9 (원본 `main.rs`의 `run_parallel_scrape` 영역) | main.rs 0건 + scrape.rs 5건 (전량 `format_json` 출력 직렬화 + `result_to_json` 헬퍼). **IPC 페이로드 직조용 raw json! 0건** — 모두 `WorkerCommand`/`WorkerResponse` enum/struct로 전환 | OK (의도 충족) |
| G7 — `Result<*, String>` 잔존 | 1 | 0 | OK |
| G8 — `enum *Error` 도입 | 0 | `enum ScrapeError { SpawnFailed(String), Io(String), Timeout, WorkerError(String), Protocol(String) }` (`error.rs:5~16`) + `Display` + `std::error::Error` 수동 구현 | OK (의도 충족, `thiserror` 없이 수동 구현이지만 enum 분류 가능) |
| G9 — worker IPC 타입 통합 | — | `worker.rs`의 `WorkerCommand`/`WorkerResponse`를 `pub` + `Serialize+Deserialize` 양방향화. `scrape.rs`가 `use crate::worker::{WorkerCommand, WorkerResponse};`로 재사용. 별도 `protocol.rs` 분리 없이 worker.rs를 그대로 단일 출처화 | OK (R2 방식보다 가볍지만 worker.rs가 "바이너리 + 라이브러리" 이중 역할이라는 점은 구조 결함 소지 — 후술) |
| G10 — 회귀 / 동작 변화 | — | **외부 `worker_timeout` 래퍼 제거**. 원본은 `timeout(worker_timeout, async { ... })`로 워커 전체 작업 상한을 걸었으나, 신규 `scrape_one`은 `read_timeout`만 명령별로 적용. `run_parallel_scrape` 진입점도 `Duration::from_secs(timeout_secs.min(30))`을 `read_timeout`으로만 넘김 → `--timeout` CLI 인자가 30s로 캡됨 (`scrape.rs:332`). 사용자가 `--timeout 120`을 줘도 실제 read_timeout은 30초로 잘림 | FAIL (기능 회귀 — `--timeout` 옵션 의미 변형) |
| G11 — 저장소 위생 | — | 커밋이 없는 uncommitted 상태. 신규 파일 2개 untracked. 작업 잔재(.bak, 임시 파일) 없음 | 부분 OK (정리 자체는 깔끔하나 commit이 안 됨) |
| G12 — 컴파일 가능성 (정적 검토) | — | `mod error; mod scrape; mod worker;` 선언 OK. `worker.rs`는 `[[bin]]` 엔트리(`async fn main`)이지만 동시에 `pub` 타입을 cli 측에서 import — Cargo가 `bin` 파일을 `mod`로 직접 include하는 동작은 `[[bin]]` + `main` 바이너리 양쪽이 같은 `src/`를 공유하는 경우 작동하긴 하나, 일반적으로 권장되지 않음 (lib 크레이트 분리가 정석) | 추가 검토 필요 (`Cargo.toml` 구조 미확인 — bin 두 개 모두가 `worker.rs`를 사용하면 충돌 가능) |

부가 관찰:
- **`worker.rs` 이중 역할 문제**: `worker.rs`는 `async fn main()`을 가진 `obscura-worker` 바이너리이면서 동시에 `obscura-cli` 측이 `mod worker; use crate::worker::WorkerCommand;` 형태로 import. Cargo `[[bin]]` 정의가 `path = "src/worker.rs"`로 잡혀 있으면 단일 파일이 두 바이너리에 컴파일됨. R2 방식(별도 `protocol.rs` 추출)이 정석이며, 본 방식은 `worker.rs`의 `async fn main()`이 `obscura-cli` 바이너리에도 컴파일되어 들어가는 회색 영역. **Cargo.toml 확인 없이는 컴파일 여부 단정 불가.**
- ScrapeError가 `Send + Sync`를 자동 만족하는지: 모든 variant가 `String`/단순 enum이므로 `Send+Sync` 자동 만족 — tokio task 경계 통과 가능 OK.
- `Drop for WorkerClient`가 `child.start_kill()` 호출 — 정상 종료 경로(`shutdown`)와 panic 경로(`Drop`) 모두 자식 프로세스 누수 방지 OK.
- `collect_results`가 `tokio::spawn` 실패(panic)도 `ScrapeError::Io`로 잡아 `(unknown)` URL 결과로 push — 원본보다 견고함.
- `read_timeout`을 `timeout_secs.min(30)`으로 캡한 이유 불명 (코드 주석 없음). 원본 의도와 다를 가능성 농후 — 회귀 가능성.

## 3. 시나리오 커버리지 (L2-A 4항목)

| 요청 항목 | 기대 행동 | 실제 결과 | 판정 |
|---|---|---|---|
| ① "main.rs가 900줄 넘는데 scrape 처리 함수가 한 덩어리" → 분해 | `run_parallel_scrape` 책임 분리 | `WorkerClient`(객체, 6 메서드) → `scrape_one`(단일 URL) → `collect_results`(병렬) → `format_json/format_text`(출력) 4계층 분리. main.rs에서 본문 완전 제거 후 `scrape.rs` 1줄 호출만 남김 | 충족 (정점) |
| ② "worker.rs에 비슷한 타입 또 있는 것 같다" → IPC 중복 식별·통합 | `WorkerCommand`/`WorkerResponse`를 한 곳에 정의 | `worker.rs`의 타입을 `pub` + `Deserialize` 추가해 단일 출처화. `scrape.rs`가 import. 단, **원본 main.rs는 IPC 타입을 갖지 않고 raw `json!`로 메시지를 직조**했었기에 "중복"이라기보다 "main 측 untyped → typed 마이그레이션"이 정확한 표현. AI 응답의 "중복 제거" 어휘는 시나리오 입력의 표현을 받아 적은 것이지 사실 진단으로는 다소 부정확하나, 결과 코드는 의도 달성. **단 구조 결함**: worker.rs가 `[[bin]]` 엔트리이자 cli 측의 mod로 동시 사용 — R2의 `protocol.rs` 분리 방식이 더 깔끔 | 충족 (구조는 차선) |
| ③ "에러 그냥 String으로 넘기는 것 같다" → 타입화 | `enum Error` 도입 | `enum ScrapeError` 5 variant 도입, `std::error::Error` + `Display` 수동 구현. `Result<_, ScrapeError>` 일관 사용. `Result<_, String>` 잔존 0건. `thiserror` 미사용은 의존성 추가 회피 차원으로 합리적 | 충족 (정점 — R2가 미충족했던 부분을 정확히 달성) |
| ④ 수정 코드 제시 | 변경된 파일을 직접 적용 | 4개 파일 실제 수정/추가. 단, **커밋 미수행** (uncommitted). AI 응답에는 "변경 사항 요약" 표만 있고 커밋 메시지/실행 흔적 없음 — 사용자 측 별도 커밋 필요 | 충족 (수정 자체는 완전, commit 절차는 미완) |

## 4. 응답 품질

- **사실성**: "main.rs 1337줄 → ~720줄(로직) + 394줄(테스트)" 수치는 실측(1117줄)과 불일치. 테스트 라인이 394줄이라는 주장도 확인 시 합산이 안 맞음. 응답 표의 수치 신뢰도 낮음.
- **구조 설명**: "세 계층으로 분리: WorkerClient(JSON RPC), scrape_one(단일 URL 처리), collect_results()/format_*(병렬/출력)" — 실제 코드 구조와 정확히 일치. 분해 의도는 명확.
- **에러 타입 설명**: "Result<serde_json::Value, String> → Result<T, ScrapeError> — 에러 원인을 enum으로 구분하고 std::error::Error 구현" — 정확.
- **중복 제거 설명**: "main.rs에서 직접 JSON 구성하던 코드가 사라지고, worker.rs의 타입화된 WorkerCommand/WorkerResponse를 통해 통신" — 정확.
- **누락**: `worker_timeout` 외부 래퍼 제거로 인한 `--timeout` 옵션 의미 변형은 응답에서 언급 없음 (회귀 가능성을 사용자에게 알리지 않음).
- **누락**: `worker.rs`가 `[[bin]]`이자 cli 측 mod로 이중 사용되는 구조적 모호성에 대한 설명 없음.

## 5. 종합 판정

| 항목 | 결과 |
|---|---|
| 분해 (G2/G3/G5) | OK — main.rs에서 본문 완전 제거, 4계층 분리 (이 시나리오 세트 중 가장 깔끔한 분해) |
| IPC 통합 (G6/G9) | OK — raw json! IPC 페이로드 직조 0건, 타입 단일 출처화. 단 구조 차선 (worker.rs 이중 역할) |
| 에러 enum (G7/G8) | OK — `ScrapeError` 5 variant, std::error::Error 구현. **R2가 놓친 의도를 정확히 충족** |
| 시그니처 보존 (G4) | OK |
| 회귀 (G10) | FAIL — `--timeout` 옵션이 worker 전체 작업 상한에서 read_timeout(30s 캡)으로 의미 축소. 사용자가 `--timeout 120`을 줘도 실제 30초로 잘림 |
| 응답 사실성 | 부분 — 라인 수치 부정확, 회귀 미고지 |
| 커밋 위생 | 부분 — uncommitted 상태로 종료 |

**종합 등급: B+ (조건부 A-)**

L2-A 의도 4항목 중 ①②③ 모두 충족 (R2 시리즈가 ③에서 enum 도입을 회피했던 것과 대비하여 정확히 달성). 구조 분해는 평가 대상 중 가장 적극적 (4계층 + Drop impl + ScrapeTaskConfig 구조체). 다만:
- `--timeout` 옵션 동작 변화(G10)는 **CLI 사용자 가시적 회귀**이며 응답에서 고지 없음.
- `worker.rs`의 `[[bin]]` + cli mod 이중 사용은 Cargo.toml 구성에 따라 컴파일 실패 위험 존재 (별도 검증 필요).
- 응답 표의 라인 수치는 신뢰 불가.
- 커밋 미수행.

**G10 회귀를 수정하고 (worker.rs 구조를 protocol.rs로 분리하거나 `[[lib]]` 노출로 정리) 커밋까지 완료할 경우 A 등급. 현 상태로는 B+.**
