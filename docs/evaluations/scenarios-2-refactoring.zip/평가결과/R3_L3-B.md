# R3 / L3-B (Collaborator · PromptCraft 완전 구조화) 평가

- 대상: `E:/Project/temp/pi/obscura-pi006` (worktree, **uncommitted**)
- 브랜치: `pi006`
- 시나리오 입력: `E:/Project/PromptCraft/시나리오2/L3-B_promptcraft.txt`
- AI 응답: `E:/Project/PromptCraft/시나리오2/결과3/L3-B_promptcraft_result.txt`
- 평가 기준: thiserror만 허용 / 새 crate 금지 / `run_parallel_scrape` 공개 시그니처 보존 / 단계별 독립 적용

## 1. 변경 요약

| 항목 | 값 |
| --- | --- |
| 커밋 수 (단계별 분할) | 0개 (uncommitted, 단일 작업 트리) |
| 변경 파일 | `Cargo.lock`, `obscura-cli/Cargo.toml`, `src/main.rs`, `src/worker.rs`, **신규** `src/ipc.rs`, **신규** `src/scrape.rs` |
| 라인 변경 (git diff --stat) | +9 / -276 (수정 파일 합계, 신규 2개 파일 별도) |
| main.rs 라인수 | 1337 → 1101 (-236) |
| worker.rs 라인수 | 144 → 109 (-35) |
| `run_parallel_scrape` 위치 | `main.rs` 본체 → `scrape.rs:26-88` (오케스트레이터 63줄) |
| 신규 모듈 | `ipc.rs` 72줄, `scrape.rs` 305줄 |
| 신규 crate | 없음 (C2 통과) |
| 추가 외부 crate | `thiserror` 1개 (C1 통과) |
| 공개 시그니처 | 보존 — `pub async fn run_parallel_scrape(urls, eval, concurrency, format, timeout_secs, quiet, proxy) -> anyhow::Result<()>` (C3 통과) |
| 호출부 변경 | `main.rs`의 직접 호출이 `scrape::run_parallel_scrape(...).await?`로 1줄 교체. import 다수 정리 |

## 2. 정량 지표 (G2~G10)

| 지표 | 결과 | 비고 |
| --- | --- | --- |
| G2 — 모듈 분리 | OK | `main.rs`에 `mod ipc; mod scrape;`, `worker.rs`에 `mod ipc;` 선언. `ipc.rs` + `scrape.rs` 신설 |
| G3 — God function 분해 | **EXCELLENT** | 230줄 본체 → 6개 함수: `run_parallel_scrape` (63줄 오케스트레이터), `resolve_worker_path` (15줄), `scrape_one` (98줄), `send_command` (19줄), `read_response` (19줄), `format_results` (39줄). 책임 경계 명확 — spawn/IPC/타임아웃/집계/포매팅 모두 분리 |
| G4 — IPC 타입 통합 | OK | `WorkerCommand` enum + `WorkerResponse` struct + `ScrapeError` enum을 `ipc.rs`로 추출. `main.rs`(=`scrape.rs`)와 `worker.rs` 양쪽이 `mod ipc;`로 참조. `serde(tag = "cmd")` rename 규칙 유지로 wire 호환. **다만 두 [[bin]] 진입점이 각각 ipc.rs를 컴파일하므로 "공유 lib crate"가 아닌 "동일 소스의 양쪽 컴파일" 방식 — 스키마 일관성은 컴파일러가 검증하나 코드 인스턴스는 두 벌** |
| G5 — Constraints (C1~C3) | **PASS** | C1: 외부 crate는 `thiserror` 1개만 추가(workspace ref) / C2: 신규 crate 디렉토리 0 / C3: `run_parallel_scrape` 7개 파라미터 + `anyhow::Result<()>` 반환 완전 동일 |
| G6 — 에러 enum 도입 | **EXCELLENT** | `ScrapeError` 6 variant + `thiserror::Error` 파생. 명령 enum(`WorkerCommand`)과 에러 enum(`ScrapeError`)이 명확히 구분됨. `#[from] std::io::Error`로 spawn 실패 자동 매핑 |
| G7 — Stringly-typed 제거 | OK | `scrape_one` 반환: `Result<serde_json::Value, ScrapeError>`. IPC 송수신 헬퍼도 `Result<_, ScrapeError>`. 코드 내 `Result<*, String>` 실사용 0건(주석 1건만 잔존: `ipc.rs:50`의 마이그레이션 설명) |
| G8 — Raw json! IPC 사용 | OK | IPC **명령** 직렬화에 `json!()` 매크로 사용 0건 — 전부 `WorkerCommand::Navigate { url }` 등 enum 인스턴스 직렬화로 대체. `json!()` 9건은 모두 결과 집계/응답 본문(`{url,title,eval,time_ms,worker}`)용으로 의도된 잔존 |
| G9 — 외부 동작 보존 | OK | JSON/TSV 출력 포맷, 종료 코드, eprintln 진행 메시지, 워커 바이너리 경로 탐색 로직 동일. `WorkerResponse`의 `{ok, result?, error?}` 직렬화 유지로 기존 worker 바이너리와 호환 |
| G10 — 단계별 적용 가능성 (incremental safety) | **N/A (미실증)** | 작업 트리가 uncommitted 단일 변경이므로 단계 분할 부재. 응답 본문은 단계별 시퀀스로 서술되었으나 git 이력으로 검증 불가. 단, 구조적으로는 ①Cargo.toml→②ipc.rs→③worker.rs migration→④scrape.rs 추출→⑤main.rs 정리 순으로 분할 가능한 형태 |

## 3. 시나리오 커버리지 (L3-B 7항목)

| # | 요구사항 | 충족 여부 | 근거 |
| --- | --- | --- | --- |
| ① | `run_parallel_scrape` 분해 | **충족** | 230줄 모놀리스 → `scrape.rs`의 1+5 구조(오케스트레이터 63줄 + 헬퍼 5개). 워커 spawn / IPC 송수신 / 타임아웃 / 결과 집계 / 포매팅 책임이 함수 단위로 깔끔히 분리 |
| ② | IPC 타입 통합 | **충족** | `ipc.rs`의 `WorkerCommand`/`WorkerResponse`를 양쪽 바이너리가 공유. `worker.rs`의 inline 정의 35줄 제거 — 진정한 단일 소스(single source of truth). `main.rs`의 raw `json!()` IPC 빌드 제거 |
| ③ | 에러 enum 도입 | **충족** | `ScrapeError` enum(Spawn/Timeout/IpcWrite/IpcRead/Navigate/UnexpectedResponse 6 variant) + `thiserror::Error` 파생. 명령 enum(`WorkerCommand`)과 의미가 명확히 구분되어 분류상의 모호함 없음. `#[from] std::io::Error`로 spawn 경로 깔끔 |
| ④ | Constraints 준수 | **충족** | thiserror 단일 추가(workspace 의존), 새 crate 0, `run_parallel_scrape` 7개 파라미터 시그니처 완전 보존(`scrape.rs:26-34`), 기존 의존성(tokio/serde/serde_json/anyhow/clap)은 모두 활용 |
| ⑤ | 각 단계 독립 적용 가능성 | **N/A** | uncommitted 상태로 단일 변경이라 단계별 cargo check 통과를 실증 불가. 시나리오 입력의 "한 단계만 적용해도 빌드 성공" 요건은 git 이력 없이는 평가 대상이 될 수 없음. 응답 텍스트는 단계 서술 형식이지만 본 평가는 워크트리 상태만을 채점 |
| ⑥ | Output Format ("단계별 안전 변환 시퀀스") | **충족** | 응답이 신규 파일 표 → 수정 파일 표 → Concern 해결 매핑 → 검증 결과의 순서로 단계별로 명시. 변경 의도와 안전성(특히 wire 호환) 서술 포함 |
| ⑦ | Related Code 4파일 활용 | **부분 충족** | `Cargo.toml`(workspace 의존성 thiserror 추가) 활용. `dispatch.rs`/`browser/lib.rs`는 직접 참조 없음 — 단, 시나리오 의도상 두 파일은 "변경 금지 영역의 호환성 확인"용 참조이므로 미변경이 정상. `worker.rs`는 명시적 마이그레이션 대상이 되어 실제로 변경됨 |

## 4. 강점 / 약점

### 강점
- **함수 분해의 정합성**: orchestrator 63줄(전체 흐름), `scrape_one` 98줄(단일 워커 생명주기), 헬퍼 3개(IPC 원자/path/포매팅)로 분해. SRP 정합도가 R2_L3-B의 `spawn_and_run_worker` 122줄보다 더 잘게 쪼개져 가독성·테스트 용이성 모두 우수.
- **에러 enum의 의미적 정확성**: `ScrapeError`가 명령 enum과 완전히 분리되고, `Spawn(#[from] std::io::Error)` / `Timeout(u64)` / `IpcWrite/IpcRead/Navigate/UnexpectedResponse`로 호출자가 종류별 분기 가능. dead variant 없음 — 6 variant 전부 실제 코드 경로에서 생성됨.
- **IPC 직렬화 우아함**: `send_command`가 `serde_json::to_string(cmd)`로 enum을 직접 직렬화 — raw `json!()` IPC 빌드 0건. 컴파일러가 명령 스키마 일관성 검증.
- **공개 시그니처 보존**: 7개 파라미터(`urls, eval, concurrency, format, timeout_secs, quiet, proxy`)와 `anyhow::Result<()>` 반환 타입이 완전 동일. `main.rs` 호출부는 `scrape::` prefix만 추가하면 됨.
- **wire 호환성**: `WorkerResponse`의 `#[serde(skip_serializing_if = "Option::is_none")]` 유지, `WorkerCommand`의 `serde(rename = ...)` 유지 — 기존 빌드된 worker 바이너리와 양방향 호환.
- **응답의 자기검증**: 응답 마지막에 cargo check/build/test (49/49 pass) 통과 + 0 warning 명시. (단, 본 평가에서 빌드 검증은 범위 밖)

### 약점 / 위험
- **단계 분할 미실증**: 시나리오 Constraints의 "각 단계는 독립적으로 적용 가능해야 함" 요건이 단일 작업 트리(uncommitted)로 처리되어 단계별 cargo check 통과를 git 이력으로 검증할 수 없음. PromptCraft Output Format("단계별 안전 변환 시퀀스")의 핵심 정신이 워크트리에 반영되지 않음. **L3-B 시리즈 공통 약점**.
- **두 바이너리의 ipc.rs 이중 컴파일**: `main.rs`와 `worker.rs`가 각자 `mod ipc;`를 선언 — 동일 소스가 두 컴파일 단위에 포함됨. lib crate(`src/lib.rs`) 추가가 더 깔끔한 단일 소스화 방법이나, 시나리오의 "새 crate 금지" 제약 해석상 lib 모듈 추가도 회피한 것으로 보임. 결과는 정상 동작하나 의미적으로는 "공유" 형태가 약함.
- **`#[allow(dead_code)]` 명시적 모듈 단위 사용**: `ipc.rs:38, 43`에서 `WorkerResponse::success/error`에, line 52에서 `ScrapeError` 전체에 `#[allow(dead_code)]`. 두 바이너리가 각자 컴파일되며 한쪽에서만 사용되는 항목이 있어 경고 회피용으로 처리됨. 구조적 한계의 부산물.
- **`scrape_one`의 shutdown 처리에서 send_command 결과 무시**: `let _ = send_command(...)` (`scrape.rs:187`) — shutdown 명령 송신 실패가 silently 무시됨. 의도된 정리 경로지만 에러 enum의 정확성 추구와 약간 어긋남.
- **`run_parallel_scrape` 결과 집계에서 URL 손실**: 응답 본문 주석(`scrape.rs:76-77`)에 "The URL is lost here because tokio::spawn erases it"라고 명시 — 원본도 동일했으나 리팩토링 기회에 `(usize, String, Result<..>)` 튜플로 복원하면 더 좋았을 부분. 외부 동작 보존 우선 정책상 수용 가능.
- **빌드 검증은 본 평가 범위 밖**: 응답이 "cargo check / build / test 49/49 pass"를 주장하지만 본 평가에서는 실행하지 않음(cargo check 금지).

## 5. 종합 등급

- **등급: A (우수)**
- 카드별 의도(Role/Goal/Modification Scope/Concern Area/Constraints/Output Format/Related Code) 거의 빠짐없이 반영. 특히 함수 분해의 입자도가 R2_L3-B 대비 더 세밀(5 helper vs 2 helper)하고, 에러 enum의 variant 분류가 의미적으로 정확.
- Constraints C1~C3 전부 통과(thiserror 단일 추가 / 새 crate 0 / 시그니처 보존). raw IPC `json!()` 0건으로 ② IPC 타입 통합의 의도를 정확히 구현.
- 감점 요소는 ⑤(단계 독립 적용)의 실증 부재 — uncommitted 단일 변경의 구조적 한계. 그리고 두 [[bin]] 진입점이 `ipc.rs`를 이중 컴파일하는 점(lib 모듈 회피의 부작용).
- 재질문 0회 / One-shot 적용 / 응답 자체의 자기검증 명시(49/49 test pass)로 L3-B 가설(One-Shot 성공률 최고치, 재질문 0회)에 부합.
- R2_L3-B 대비 함수 분해의 입자도, 에러 enum의 variant 의미 정확성에서 우위. 단계 독립 적용 실증 부재는 동일 약점이므로 등급 차이를 만들 정도는 아님.
