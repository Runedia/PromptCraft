# R2 L3-A (Collaborator / 일반 자연어) 평가

- 평가 대상 폴더: `E:/Project/PromptCraft/시나리오2/project/obscura_R2_L3-A`
- 평가 브랜치/커밋: `gem005` HEAD = `01cc8dd "L3-A"` (단일 커밋)
- 시나리오 입력: `E:/Project/PromptCraft/시나리오2/L3-A_일반.txt`
- AI 응답: `E:/Project/PromptCraft/시나리오2/결과2/L3-A_일반_result.txt`
- 평가 일자: 2026-05-22

## 0. 작업 범위 확인

L3-A 커밋이 만진 파일(`git show --stat 01cc8dd`):

| 파일 | 변경 |
|---|---|
| `crates/obscura-cli/src/main.rs` | +/− 356줄 (재구성) |
| `crates/obscura-cli/src/ipc.rs` | 신규 +44줄 |
| `crates/obscura-cli/src/worker.rs` | −37줄 (타입 정의 제거) |
| `crates/obscura-cli/Cargo.toml` | +1줄 (`thiserror` 추가) |
| `Cargo.lock` | +1줄 |

총 +244 / −195. 단일 커밋, 단계별 커밋 분할 없음.

## 1. 정량 지표 (G2~G10)

| ID | 지표 | 원본(main) | 결과 | 평가 |
|---|---|---|---|---|
| G2 | `main.rs` 총 줄 수 | 1337 | **1373** (+36) | △ — 분해 후에도 길이가 줄지 않음 (테스트·신규 헬퍼 합산 효과). 의미 단위 분해는 했지만 총량 감축은 미흡 |
| G3 | `run_parallel_scrape` 길이 | 230줄 (main.rs:687~) | **96줄** (main.rs:864~959) | ◎ −134줄(약 58% 감소). 외부 루프·세마포어·타임아웃·결과 수신만 남고 단일 URL 처리·집계 등 위임 |
| G4 | 분해 함수 수 (신규) | 0 | **5개** + 보조 struct 1개 | ◎ `spawn_worker(714)` / `send_command(733)` / `read_response(744)` / `scrape_single_url(759)` / `aggregate_results(820)` + `struct WorkerHandles(708)` |
| G5 | IPC 타입 정의 위치 | `worker.rs` 단일 | **`ipc.rs` (mod ipc)** 공유 | ◎ `WorkerCommand`(6 variant), `WorkerResponse` + `success/error` 생성자. `main.rs:10-11`에서 `mod ipc; use ipc::{WorkerCommand, WorkerResponse};` 사용. `worker.rs`도 동일 모듈 사용 |
| G6 | IPC raw JSON 매크로 잔존 | 다수 (`serde_json::json!({"cmd":...})`) | **scrape 경로에서 0개** | ◎ `Navigate / Evaluate / Shutdown` 모두 `WorkerCommand::*` enum 사용. 응답 측은 `WorkerResponse` 역직렬화. (결과 직렬화용 `json!({"url":..., "title":...})`은 외부 출력 페이로드이므로 별개) |
| G7 | 에러 타입 | `Result<Value, String>` (stringly-typed) | **`Result<_, ScrapeError>`** | ◎ `#[derive(thiserror::Error)]`, 7개 variant: `SpawnFailed(#[source] io::Error)` / `StdinFailed` / `StdoutFailed` / `WriteFailed` / `ReadFailed` / `Timeout` / `WorkerError(String)` |
| G8 | thiserror 의존성 | 없음 | **추가됨** (`workspace = true`) | ◎ 요구사항 "thiserror 정도까지 허용" 준수. 추가 외부 crate 없음 |
| G9 | 단계별 커밋 분할 | — | **1개 커밋 ("L3-A")** | ✗ 사용자가 "1) 2) 3) 세 단계로 진행"을 명시했음에도 단일 커밋. git 히스토리에서 단계별 진행 미보장. 응답 본문에서는 단계로 서술 |
| G10 | 외부 동작 보존 메커니즘 | — | **에러 메시지 문자열 동일성 유지** | ○ `#[error("...")]` 포맷이 원본 문자열("Failed to spawn worker: ...", "timeout", "navigate failed" 등)과 정합. 응답에서도 `error.to_string()` 동일성 명시. 단, 검증 자동화 부재 (테스트는 기존 13개 유지, 신규 회귀 테스트 없음) |

추가 관측치
- `cargo check` 미실행 (지시에 따름). 컴파일 가능성은 코드 정적 검토상 문제 없어 보임. `ipc.rs`가 `crates/obscura-cli/src/`에 위치하여 `mod ipc;` 선언만으로 `main.rs`·`worker.rs` 양쪽에서 접근 가능.
- 응답 본문 마지막의 "`cargo check` 및 `cargo test`를 통과했으며 … cargo run으로 동작 확인" 주장은 AI 응답 측 자기보고이며 실행 증거(테스트 로그, 빌드 출력)가 응답에 첨부되지 않음.

## 2. 시나리오 커버리지 (L3-A 5항목)

| # | 요구 | 응답 충족 | 코드 충족 | 비고 |
|---|---|---|---|---|
| ① | `run_parallel_scrape` 분해 | ◎ | ◎ | 응답이 명시한 5개 헬퍼와 실제 코드 1:1 일치 (`spawn_worker / send_command / read_response / scrape_single_url / aggregate_results`). 230→96줄 |
| ② | IPC 타입 통합 (raw JSON → 타입 사용) | ◎ | ◎ | `ipc.rs` 모듈 신설, main 측 `serde_json::json!({"cmd": ...})` 경로 제거, `WorkerCommand` enum 사용 |
| ③ | 에러 enum 도입 (`Result<Value, String>` → `ScrapeError`) | ◎ | ◎ | `thiserror` 기반 7-variant enum. `#[source]`로 `io::Error` 체인 보존 |
| ④ | Fowler 카탈로그 매핑 언급 | ◎ | n/a | 단계 1 → Extract Module / Extract Class, 단계 2 → Replace Error Code with Exception, 단계 3 → Extract Function. 3개 매핑 모두 명시 |
| ⑤ | 단계별 diff | ○ | ✗ | 응답에는 3단계 각각의 변경 전후 diff 요약 블록을 포함(짧지만 존재). 그러나 **git 단계별 커밋은 없음(단일 커밋)**. "단계별 diff 요구"가 응답 서술상의 단계 분리만 의미한다면 충족, 커밋 단위 검증을 요구한다면 미충족 |

부수 사항
- "외부 동작(CLI 출력 형식, 종료 코드) 보존" 추가 요구는 응답이 각 단계마다 보존 여부를 짚었고(단계 2의 에러 문자열 매칭 항목 등), 코드 측에서도 에러 메시지 포맷이 보존됨. 다만 회귀 테스트는 추가되지 않음.
- "외부 crate 추가는 thiserror까지" 제약: 준수.

## 3. 약점·리스크

1. **단계별 커밋 분할 부재 (G9, ⑤)** — 사용자가 "이 세 단계로 진행"이라고 명시했고 L3 가설("작업을 3단계 이상으로 명시적으로 분해")의 측정 대상임에도 git 히스토리는 단일 커밋. 단계 간 회귀 시점을 분리해 검증할 수 없음.
2. **회귀 검증 자동화 부재** — `ScrapeError`의 `error.to_string()`이 기존 메시지와 동일한지에 대한 단위 테스트가 없음. 외부 동작 보존 주장은 수동 검증 + AI 자가보고에 의존.
3. **`main.rs` 총량 미감축** — 분해를 통한 응집도 개선은 명확하나, 총 줄 수가 오히려 36줄 증가(1337 → 1373). `WorkerHandles` struct, `ScrapeError` enum, 5개 헬퍼가 모두 같은 파일에 추가되었기 때문. `scrape.rs` 같은 별도 모듈로 분리하면 `main.rs` 자체의 책임 축소가 더 분명했을 것.
4. **단계 2 diff의 깊이 부족** — 응답의 "단계 1" diff 블록이 `worker.rs`에서 enum 정의 제거 + `mod ipc;` 추가만 보여주고 `ipc.rs` 신규 파일 내용 전체는 보여주지 않음. 단계 3 diff도 단편적. 시나리오의 "변경 전후 diff" 요구 강도에 비해 분량이 얇음.
5. **`WorkerCommand`에 누락 가능 variant** — `ipc.rs`의 `WorkerCommand`는 `Navigate / Evaluate / Title / DumpHtml / DumpText / Shutdown` 6개. 원본 `worker.rs`가 더 많은 명령을 처리했는지 확인 필요(이번 평가 범위에서는 미검증).

## 4. 종합 등급

| 축 | 점수 |
|---|---|
| 코드 변경 충실도 (G2~G8) | A (분해·타입 통합·에러 enum 모두 구현, 외부 crate 제약 준수) |
| 외부 동작 보존 (G10) | B+ (메커니즘 명시되었으나 자동 검증 부재) |
| 프로세스 (G9, ⑤) | C (단계별 커밋 분리 미실행) |
| 응답 품질 (Fowler 매핑·구조) | A− (3패턴 매핑 명료, 단 diff 분량은 얕음) |

**종합: B+ (4/5)**

- L3-A의 핵심 작업(분해 / IPC 통합 / 에러 enum / Fowler 매핑)은 모두 실코드에 반영되어 One-Shot 성공률 가설과 정합.
- 다만 시나리오 가설 중 "작업을 3단계 이상으로 명시적으로 분해"가 응답 서술에 머무르고 git 단계 커밋으로 이어지지 않은 점이 감점 요인.
- "AI가 일부 항목을 빠뜨릴 위험" 가설은 부분 적중: 응답이 단계별 diff를 짧게 처리했고, 회귀 테스트 추가 없이 "보존 확인" 자가보고로 마무리.
